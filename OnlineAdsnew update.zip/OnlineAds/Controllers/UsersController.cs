﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using OnlineAds.Models;
using System.Security.Claims;

namespace OnlineAds.Controllers
{
    public class UsersController : Controller
    {
        private readonly ILogger<UsersController> _logger;
        private readonly DbemarketingContext _context;
        private readonly IWebHostEnvironment _env;

        public UsersController(ILogger<UsersController> logger, DbemarketingContext context, IWebHostEnvironment env)
        {
            _logger = logger;
            _context = context;
            _env = env;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(string email, string password)
        {
            var user = _context.TblUsers.SingleOrDefault(u => u.UEmail == email && u.UPassword == password);
            if (user == null)
            {
                ViewBag.ErrorMessage = "Invalid login attempt.";
                return View();
            }

            //var claims = new List<Claim>
            //{
            //    new Claim(ClaimTypes.NameIdentifier, user.UId.ToString()),
            //    new Claim(ClaimTypes.Name, user.UName),
            //    new Claim(ClaimTypes.Email, user.UEmail)
            //};
            //var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            //var principal = new ClaimsPrincipal(identity);
            //await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);

            return RedirectToAction("Index", "Home");
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Register(string name, string email, string password, string contact, string city, string state, DateTime dob, string gender, IFormFile imageFile)
        {
            if (_context.TblUsers.Any(u => u.UEmail == email))
            {
                ViewBag.ErrorMessage = "Email address is already in use.";
                return View();
            }

            var user = new TblUser
            {
                UName = name,
                UEmail = email,
                UPassword = password,
                UContact = contact,
                UCity = city,
                UState = state,
                UDateofbirth = dob,
                UGender = gender
            };
            if (imageFile != null && imageFile.Length > 0)
            {
                var imageName = Guid.NewGuid().ToString() + Path.GetExtension(imageFile.FileName);
                var imagePath = Path.Combine(_env.WebRootPath, "images", imageName);
                using (var stream = new FileStream(imagePath, FileMode.Create))
                {
                    await imageFile.CopyToAsync(stream);
                }
                user.UImage = imageName;
            }

            _context.TblUsers.Add(user);
            await _context.SaveChangesAsync();

            //var claims = new List<Claim>
            //{
            //    new Claim(ClaimTypes.NameIdentifier, user.UId.ToString()),
            //    new Claim(ClaimTypes.Name, user.UName),
            //    new Claim(ClaimTypes.Email, user.UEmail)
            //};
            //var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            //var principal = new ClaimsPrincipal(identity);
            //await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);

            return RedirectToAction("Index", "Home");
        }

        [HttpGet]
        public IActionResult CreateProduct(int categoryId)
        {
            var category = _context.TblCategories.Find(categoryId);
            if (category == null)
            {
                return NotFound();
            }

            var product = new TblProduct
            {
                CatId = categoryId,
                TblCategory = category
            };

            return View(product);
        }

        [HttpPost]
        public async Task<IActionResult> CreateProduct(TblProduct product, IFormFile imageFile)
        {
            if (ModelState.IsValid)
            {
                if (imageFile != null && imageFile.Length > 0)
                {
                    var imageName = Guid.NewGuid().ToString() + Path.GetExtension(imageFile.FileName);
                    var imagePath = Path.Combine(_env.WebRootPath, "images", imageName);
                    using (var stream = new FileStream(imagePath, FileMode.Create))
                    {
                        await imageFile.CopyToAsync(stream);
                    }
                    product.ProImage = imageName;
                }

                _context.TblProducts.Add(product);
                await _context.SaveChangesAsync();

                return RedirectToAction("CategoryDetails", "Categories", new { id = product.CatId });
            }

            return View(product);
        }
    }
}
