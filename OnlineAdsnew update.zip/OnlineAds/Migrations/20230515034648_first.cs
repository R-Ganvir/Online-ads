﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace OnlineAds.Migrations
{
    /// <inheritdoc />
    public partial class first : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "sysdiagrams",
                columns: table => new
                {
                    diagramid = table.Column<int>(name: "diagram_id", type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    name = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    principalid = table.Column<int>(name: "principal_id", type: "int", nullable: false),
                    version = table.Column<int>(type: "int", nullable: true),
                    definition = table.Column<byte[]>(type: "varbinary(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_sysdiagrams", x => x.diagramid);
                });

            migrationBuilder.CreateTable(
                name: "tbl_admin",
                columns: table => new
                {
                    adid = table.Column<int>(name: "ad_id", type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    adusername = table.Column<string>(name: "ad_username", type: "nvarchar(50)", maxLength: 50, nullable: false),
                    adpassword = table.Column<string>(name: "ad_password", type: "nvarchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbl_admin", x => x.adid);
                });

            migrationBuilder.CreateTable(
                name: "tbl_user",
                columns: table => new
                {
                    uid = table.Column<int>(name: "u_id", type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    upassword = table.Column<string>(name: "u_password", type: "nvarchar(9)", maxLength: 9, nullable: false),
                    uname = table.Column<string>(name: "u_name", type: "nvarchar(15)", maxLength: 15, nullable: false),
                    udateofbirth = table.Column<DateTime>(name: "u_dateofbirth", type: "date", nullable: false),
                    ugender = table.Column<string>(name: "u_gender", type: "nvarchar(7)", maxLength: 7, nullable: false),
                    ucity = table.Column<string>(name: "u_city", type: "nvarchar(10)", maxLength: 10, nullable: false),
                    ustate = table.Column<string>(name: "u_state", type: "nvarchar(15)", maxLength: 15, nullable: false),
                    uemail = table.Column<string>(name: "u_email", type: "nvarchar(30)", maxLength: 30, nullable: false),
                    uimage = table.Column<string>(name: "u_image", type: "nvarchar(max)", nullable: false),
                    ucontact = table.Column<string>(name: "u_contact", type: "nvarchar(10)", maxLength: 10, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbl_user", x => x.uid);
                });

            migrationBuilder.CreateTable(
                name: "tbl_category",
                columns: table => new
                {
                    catid = table.Column<int>(name: "cat_id", type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    catname = table.Column<string>(name: "cat_name", type: "nvarchar(50)", maxLength: 50, nullable: false),
                    catimage = table.Column<string>(name: "cat_image", type: "nvarchar(max)", nullable: false),
                    catfkad = table.Column<int>(name: "cat_fk_ad", type: "int", nullable: true),
                    catstatus = table.Column<int>(name: "cat_status", type: "int", nullable: true),
                    catsubcatname = table.Column<string>(name: "cat_subcatname", type: "nchar(20)", fixedLength: true, maxLength: 20, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbl_category", x => x.catid);
                    table.ForeignKey(
                        name: "FK__tbl_categ__cat_f__276EDEB3",
                        column: x => x.catfkad,
                        principalTable: "tbl_admin",
                        principalColumn: "ad_id");
                });

            migrationBuilder.CreateTable(
                name: "tbl_product",
                columns: table => new
                {
                    proid = table.Column<int>(name: "pro_id", type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    proname = table.Column<string>(name: "pro_name", type: "nvarchar(50)", maxLength: 50, nullable: false),
                    proimage = table.Column<string>(name: "pro_image", type: "nvarchar(max)", nullable: false),
                    prodes = table.Column<string>(name: "pro_des", type: "nvarchar(max)", nullable: false),
                    proprice = table.Column<int>(name: "pro_price", type: "int", nullable: true),
                    profkcat = table.Column<int>(name: "pro_fk_cat", type: "int", nullable: true),
                    profkuser = table.Column<int>(name: "pro_fk_user", type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbl_product", x => x.proid);
                    table.ForeignKey(
                        name: "FK__tbl_produ__pro_f__2E1BDC42",
                        column: x => x.profkcat,
                        principalTable: "tbl_category",
                        principalColumn: "cat_id");
                    table.ForeignKey(
                        name: "FK__tbl_produ__pro_f__2F10007B",
                        column: x => x.profkuser,
                        principalTable: "tbl_user",
                        principalColumn: "u_id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_FK__tbl_categ__cat_f__276EDEB3",
                table: "tbl_category",
                column: "cat_fk_ad");

            migrationBuilder.CreateIndex(
                name: "IX_FK__tbl_produ__pro_f__2E1BDC42",
                table: "tbl_product",
                column: "pro_fk_cat");

            migrationBuilder.CreateIndex(
                name: "IX_FK__tbl_produ__pro_f__2F10007B",
                table: "tbl_product",
                column: "pro_fk_user");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "sysdiagrams");

            migrationBuilder.DropTable(
                name: "tbl_product");

            migrationBuilder.DropTable(
                name: "tbl_category");

            migrationBuilder.DropTable(
                name: "tbl_user");

            migrationBuilder.DropTable(
                name: "tbl_admin");
        }
    }
}
